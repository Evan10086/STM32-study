#ifndef __USART_H__
#define __USART_H__



extern void usart1_init(uint32_t baud);


#endif
