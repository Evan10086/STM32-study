#ifndef __RTC_H__
#define __RTC_H__



extern void rtc_init(void);







#endif
