#ifndef __KEY_H__
#define __KEY_H__

extern void key_init(void);
	

#endif
