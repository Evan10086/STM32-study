#ifndef __PWM_H__
#define __PWM_H__



extern void pwm_init(void);

extern void pwm_led(uint32_t freq,uint32_t duty);








#endif



